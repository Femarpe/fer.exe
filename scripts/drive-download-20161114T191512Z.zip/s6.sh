#!/bin/bash

while [ -e /etc/ts.comf ]
do
	curl  http://www.google.es /dev/null
done
