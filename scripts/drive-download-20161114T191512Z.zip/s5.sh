#!/bin/bash

# niano niano
if touch /bin/paco
then
	echo "si"
elif ls
then
	echo "no se"
else
	echo "no"
fi
