#!/bin/bash

if [ $# !> 2 ]
then 
	echo "GlaDos: bien $1"
else
	echo "Glados: mal echo se pone: sh $0 ··· ···"
fi
