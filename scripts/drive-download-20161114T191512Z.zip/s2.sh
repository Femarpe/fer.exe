#!/in/bash
echo "$0" #ceroooooo
echo "$?"
echo "$#"
echo "$1"
echo "$2"
